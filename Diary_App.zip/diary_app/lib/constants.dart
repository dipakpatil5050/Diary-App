const months = {
  1: {'JAN': 31}, // month No : {month:days in month}
  2: {'FEB': 28},
  3: {'MAR': 31},
  4: {'APR': 30},
  5: {'MAY': 31},
  6: {'JUN': 30},
  7: {'JUL': 31},
  8: {'AUG': 31},
  9: {'SEP': 30},
  10: {'OCT': 31},
  11: {'NOV': 30},
  12: {'DEC': 31}
};
